
const websocket = undefined;

// const getWebsocket = () => {
//     websocket = websocket || new WebSocket();
//     return websocket;
// }

export async function watch() {
    // websocket = getWebsocket();
    // websocket.onopen = () => {
    //     console.log( 'Websocket Open!!!' );
    // }
}


